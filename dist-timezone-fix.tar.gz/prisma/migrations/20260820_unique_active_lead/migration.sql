-- =====================================================
-- Migration: Prevent Duplicate Active Leads
-- Date: 2026-08-20
-- Purpose: Add unique constraint to prevent multiple
--          active leads for the same client
-- =====================================================

-- Step 1: Close duplicate active leads (keep newest)
-- This will run BEFORE applying the constraint
WITH duplicates AS (
  SELECT 
    "clientId",
    ARRAY_AGG(id ORDER BY "createdAt" DESC) as lead_ids
  FROM leads
  WHERE status IN ('NEW', 'ASSIGNED', 'CALLING', 'FOLLOW_UP')
  GROUP BY "clientId"
  HAVING COUNT(*) > 1
)
UPDATE leads
SET 
  status = 'CLOSED',
  "updatedAt" = NOW()
WHERE id IN (
  SELECT UNNEST(lead_ids[2:]) FROM duplicates
);

-- Step 2: Create unique partial index
-- Only one active lead per client allowed
CREATE UNIQUE INDEX IF NOT EXISTS "idx_unique_active_lead" 
ON leads ("clientId") 
WHERE status IN ('NEW', 'ASSIGNED', 'CALLING', 'FOLLOW_UP');

-- Step 3: Add comment for documentation
COMMENT ON INDEX "idx_unique_active_lead" IS 
'Ensures only one active lead per client. Prevents race conditions in webhook processing.';
